package Test;

    import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.Assert;
	import org.testng.annotations.AfterClass;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.Test;

	public class LoginAndRecoveryTest {

	    private WebDriver driver;

	    @BeforeClass
	    public void setUp() {
	     
	        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
	        driver = new ChromeDriver();
	        driver.get("url_of_your_web_application_login_page");
	    }

	    @Test(priority = 1)
	    public void testValidLogin() {
	        // Test Case 1: Verify that a user with valid credentials can successfully log in
	        login("valid_username", "valid_password");

	        Assert.assertTrue(isLoggedIn(), "Login failed for valid credentials");
	    }

	    @Test(priority = 2)
	    public void testInvalidLogin() {
	        // Test Case 2: Validate that an error message is displayed with invalid credentials
	        login("invalid_username", "invalid_password");

	        // Assertion: Check for the presence of the error message element
	        Assert.assertTrue(isErrorMessageDisplayed(), "Error message not displayed for invalid login");

	        // Test Case 3: Ensure that the login page retains entered values after a failed attempt
	        Assert.assertEquals(getUsernameFieldValue(), "invalid_username", "Username not retained");
	        Assert.assertEquals(getPasswordFieldValue(), "invalid_password", "Password not retained");
	    }

	    @Test(priority = 3)
	    public void testEmptyFields() {
	        // Test Case 4: Test that the 'Login' button is disabled when both fields are empty
	        Assert.assertFalse(isLoginButtonEnabled(), "Login button is enabled with empty fields");

	        // Test Case 5: Confirm that the 'Login' button is enabled only when both fields have valid input
	        fillLoginFields("valid_username", "valid_password");
	        Assert.assertTrue(isLoginButtonEnabled(), "Login button is disabled with valid input");
	    }

	    @Test(priority = 4)
	    public void testForgotPassword() {
	        // Test Case 6: Verify that clicking the 'Forgot Password' link redirects to the password recovery page
	        clickForgotPassword();
	        Assert.assertTrue(isOnPasswordRecoveryPage(), "Not redirected to password recovery page");

	        // Test Case 7: Validate the password recovery functionality (skipping email verification)
	        enterEmailForRecovery("valid_email@example.com");
	        clickRecoverPassword();

	        Assert.assertTrue(isRecoverySuccessMessageDisplayed(), "Recovery success message not displayed");
	    }

	    @AfterClass
	    public void tearDown() {
	        driver.quit();
	    }

	    private void login(String username, String password) {
	        fillLoginFields(username, password);
	        clickLoginButton();
	    }

	    private void fillLoginFields(String username, String password) {
	    	driver.findElement(By.id("username")).sendKeys(username);
	        driver.findElement(By.id("password")).sendKeys(password);
	    }

	    private void clickLoginButton() {
	    	driver.findElement(By.id("loginButton")).click();
	    }

	    private boolean isLoggedIn() {
	        return driver.getPageSource().contains("Welcome");
	    }

	    private boolean isErrorMessageDisplayed() {
	        return driver.getPageSource().contains("Invalid credentials");
	    }

	    private String getUsernameFieldValue() {
	        return driver.findElement(By.id("username")).getAttribute("value");
	    }

	    private String getPasswordFieldValue() {
	        return driver.findElement(By.id("password")).getAttribute("value");
	    }

	    private boolean isLoginButtonEnabled() {
	        return driver.findElement(By.id("loginButton")).isEnabled();
	    }

	    private void clickForgotPassword() {
	        driver.findElement(By.linkText("Forgot Password")).click();
	    }

	    private boolean isOnPasswordRecoveryPage() {
	        return driver.getPageSource().contains("Reset Password");
	    }

	    private void enterEmailForRecovery(String email) {
	        driver.findElement(By.id("recoveryEmail")).sendKeys(email);
	    }

	    private void clickRecoverPassword() {
	        driver.findElement(By.id("recoverButton")).click();
	    }

	    private boolean isRecoverySuccessMessageDisplayed() {
	        return driver.getPageSource().contains("Recovery instructions sent");
	    }
	}



